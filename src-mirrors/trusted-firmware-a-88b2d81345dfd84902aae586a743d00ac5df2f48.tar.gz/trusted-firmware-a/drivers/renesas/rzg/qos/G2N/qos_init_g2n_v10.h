/*
 * Copyright (c) 2021, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_G2N_V10_H
#define QOS_INIT_G2N_V10_H

void qos_init_g2n_v10(void);

#endif /* QOS_INIT_G2N_V10_H */
