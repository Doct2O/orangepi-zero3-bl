/*
 * Copyright (c) 2015-2017, Renesas Electronics Corporation
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_H_V3M__
#define QOS_INIT_H_V3M__

void qos_init_v3m(void);

#endif	/* QOS_INIT_H_V3M__ */
