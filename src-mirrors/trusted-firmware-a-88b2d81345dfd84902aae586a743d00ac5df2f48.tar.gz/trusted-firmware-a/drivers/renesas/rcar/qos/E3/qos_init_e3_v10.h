/*
 * Copyright (c) 2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_E3_V10_H
#define QOS_INIT_E3_V10_H

void qos_init_e3_v10(void);

#endif /* QOS_INIT_E3_V10_H */
