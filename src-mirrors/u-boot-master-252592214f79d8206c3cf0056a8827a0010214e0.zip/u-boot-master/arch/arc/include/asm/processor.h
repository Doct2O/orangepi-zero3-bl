/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2015 Synopsys, Inc. All rights reserved.
 */

#ifndef _ASM_ARC_PROCESSOR_H
#define _ASM_ARC_PROCESSOR_H

/* This file is required by some generic code like USB etc */

#endif /* _ASM_ARC_PROCESSOR_H */
