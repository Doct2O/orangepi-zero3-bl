/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2017 NXP
 */

#ifndef __ASM_ARCH_IMX8M_GPIO_H
#define __ASM_ARCH_IMX8M_GPIO_H

#include <asm/mach-imx/gpio.h>

#endif
